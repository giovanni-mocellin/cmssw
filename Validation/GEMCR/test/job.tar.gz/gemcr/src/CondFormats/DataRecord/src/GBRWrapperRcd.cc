// -*- C++ -*-
//
// Package:     DataRecord
// Class  :     GBRWrapperRcd
// 
// Implementation:
//     [Notes on implementation]
//
// Author:      
// Created:     Tue Nov  8 22:18:56 CET 2011
// $Id$

#include "CondFormats/DataRecord/interface/GBRWrapperRcd.h"
#include "FWCore/Framework/interface/eventsetuprecord_registration_macro.h"

EVENTSETUP_RECORD_REG(GBRWrapperRcd);
