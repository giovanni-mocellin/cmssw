// -*- C++ -*-
//
// Package:     DataRecord
// Class  :     TTUBoardSpecsRcd
// 
// Implementation:
//     <Notes on implementation>
//
// Author:      
// Created:     Thu Dec 11 17:47:39 CET 2008
// $Id$

#include "CondFormats/DataRecord/interface/TTUBoardSpecsRcd.h"
#include "FWCore/Framework/interface/eventsetuprecord_registration_macro.h"

EVENTSETUP_RECORD_REG(TTUBoardSpecsRcd);
