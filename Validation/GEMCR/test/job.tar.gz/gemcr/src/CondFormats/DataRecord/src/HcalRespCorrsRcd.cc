// -*- C++ -*-
//
// Package:     DataRecord
// Class  :     HcalRespCorrsRcd
// 
// Implementation:
//     <Notes on implementation>
//
// Author:      
// Created:     Sat Mar  1 15:49:28 CET 2008
// $Id$

#include "CondFormats/DataRecord/interface/HcalRespCorrsRcd.h"
#include "FWCore/Framework/interface/eventsetuprecord_registration_macro.h"

EVENTSETUP_RECORD_REG(HcalRespCorrsRcd);
