// -*- C++ -*-
//
// Package:     DataRecord
// Class  :     RPCObPVSSmapRcd
// 
// Implementation:
//     <Notes on implementation>
//
// Author:      
// Created:     Wed Oct 15 21:38:05 CEST 2008
// $Id$

#include "CondFormats/DataRecord/interface/RPCObPVSSmapRcd.h"
#include "FWCore/Framework/interface/eventsetuprecord_registration_macro.h"

EVENTSETUP_RECORD_REG(RPCObPVSSmapRcd);
