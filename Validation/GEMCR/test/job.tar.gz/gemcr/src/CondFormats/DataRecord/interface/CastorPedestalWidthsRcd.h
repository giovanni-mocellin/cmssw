#ifndef DataRecord_CastorPedestalWidthsRcd_h
#define DataRecord_CastorPedestalWidthsRcd_h
// -*- C++ -*-
//
// Package:     DataRecord
// Class  :     CastorPedestalWidthsRcd
// 
/**\class CastorPedestalWidthsRcd CastorPedestalWidthsRcd.h CondFormats/DataRecord/interface/CastorPedestalWidthsRcd.h

 Description: <one line class summary>

 Usage:
    <usage>

*/
//
// Author:      
// Created:     Mon Feb 11 12:18:02 CET 2008
// $Id: CastorPedestalWidthsRcd.h,v 1.1 2008/02/15 15:53:04 mccauley Exp $
//

#include "FWCore/Framework/interface/EventSetupRecordImplementation.h"

class CastorPedestalWidthsRcd : public edm::eventsetup::EventSetupRecordImplementation<CastorPedestalWidthsRcd> {};

#endif
