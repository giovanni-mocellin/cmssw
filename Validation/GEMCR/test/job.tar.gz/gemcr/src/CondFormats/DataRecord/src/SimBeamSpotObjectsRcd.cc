// -*- C++ -*-
//
// Package:     DataRecord
// Class  :     SimBeamSpotObjectsRcd
// 
// Implementation:
//     <Notes on implementation>
//
// Author:      
// Created:     Tue Mar  6 19:34:33 CST 2007
// $Id: SimBeamSpotObjectsRcd.cc,v 1.1 2012/01/06 02:34:07 vlimant Exp $

#include "CondFormats/DataRecord/interface/SimBeamSpotObjectsRcd.h"
#include "FWCore/Framework/interface/eventsetuprecord_registration_macro.h"

EVENTSETUP_RECORD_REG(SimBeamSpotObjectsRcd);
