// -*- C++ -*-
//
// Package:     OptAlignObjects
// Class  :     PX_sensorsRcd
// 
// Implementation:
//     <Notes on implementation>
//
// Author:      
// Created:     Thu Jul 20 14:30:27 CEST 2006
// $Id: PX_sensorsRcd.cc,v 1.1 2006/08/01 12:00:11 kdziedzi Exp $

#include "CondFormats/DataRecord/interface/PXsensorsRcd.h"
#include "FWCore/Framework/interface/eventsetuprecord_registration_macro.h"

EVENTSETUP_RECORD_REG(PXsensorsRcd);
