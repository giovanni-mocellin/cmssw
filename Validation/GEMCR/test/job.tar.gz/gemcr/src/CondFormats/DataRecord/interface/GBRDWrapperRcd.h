#ifndef DataRecord_GBRDWrapperRcd_h
#define DataRecord_GBRDWrapperRcd_h
// -*- C++ -*-
//
// Package:     DataRecord
// Class  :     GBRDWrapperRcd
// 
/**\class GBRDWrapperRcd GBRDWrapperRcd.h CondFormats/DataRecord/interface/GBRDWrapperRcd.h

 Description: [one line class summary]

 Usage:
    <usage>

*/
//
// Author:      
// Created:     Tue Nov  8 22:18:56 CET 2011
// $Id$
//

#include "FWCore/Framework/interface/EventSetupRecordImplementation.h"

class GBRDWrapperRcd : public edm::eventsetup::EventSetupRecordImplementation<GBRDWrapperRcd> {};

#endif
