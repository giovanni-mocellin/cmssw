// Package: CondFormats
// Class  : DYTThrObjectRcd
//
// Author: D. Pagano - UCL Louvain     

#include "CondFormats/DataRecord/interface/DYTThrObjectRcd.h"
#include "FWCore/Framework/interface/eventsetuprecord_registration_macro.h"

EVENTSETUP_RECORD_REG(DYTThrObjectRcd);
