// -*- C++ -*-
//
// Package:     DataRecord
// Class  :     PixelCPEParmErrorsRcd
// 
// Implementation:
//     <Notes on implementation>
//
// Author:      
// Created:     Fri Aug 17 08:18:51 CDT 2007
// $Id$

#include "CondFormats/DataRecord/interface/PixelCPEParmErrorsRcd.h"
#include "FWCore/Framework/interface/eventsetuprecord_registration_macro.h"

EVENTSETUP_RECORD_REG(PixelCPEParmErrorsRcd);
