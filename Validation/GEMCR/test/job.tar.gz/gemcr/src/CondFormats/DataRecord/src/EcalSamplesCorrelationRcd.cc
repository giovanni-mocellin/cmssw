// -*- C++ -*-

// Author:      Jean Fay
// Created:     Monday, 24 Nov 2014

#include "CondFormats/DataRecord/interface/EcalSamplesCorrelationRcd.h"
#include "FWCore/Framework/interface/eventsetuprecord_registration_macro.h"

EVENTSETUP_RECORD_REG(EcalSamplesCorrelationRcd);
