// -*- C++ -*-
//
// Package:     CondFormats/DataRecord
// Class  :     GEMEMapRcd
// 
// Implementation:
//     [Notes on implementation]
//
// Author:      Simranjit Singh Chhibra
// Created:     Sun, 06 Nov 2016 22:44:57 GMT

#include "CondFormats/DataRecord/interface/GEMEMapRcd.h"
#include "FWCore/Framework/interface/eventsetuprecord_registration_macro.h"

EVENTSETUP_RECORD_REG(GEMEMapRcd);
