// -*- C++ -*-
//
// Package:     DataRecord
// Class  :     L1TriggerKeyRcd
// 
// Implementation:
//     <Notes on implementation>
//
// Author:      
// Created:     Tue Jul 17 19:15:08 CEST 2007
// $Id$

#include "CondFormats/DataRecord/interface/L1TriggerKeyRcd.h"
#include "FWCore/Framework/interface/eventsetuprecord_registration_macro.h"

EVENTSETUP_RECORD_REG(L1TriggerKeyRcd);
