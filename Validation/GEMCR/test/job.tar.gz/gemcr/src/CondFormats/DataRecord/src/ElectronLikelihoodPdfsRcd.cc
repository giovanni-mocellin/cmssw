// -*- C++ -*-
//
// Package:     DataRecord
// Class  :     ElectronLikelihoodPdfsRcd
// 
// Implementation:
//     <Notes on implementation>
//
// Author:      
// Created:     Wed Sep  5 16:36:25 CEST 2007
// $Id$

#include "CondFormats/DataRecord/interface/ElectronLikelihoodPdfsRcd.h"
#include "FWCore/Framework/interface/eventsetuprecord_registration_macro.h"

EVENTSETUP_RECORD_REG(ElectronLikelihoodPdfsRcd);
