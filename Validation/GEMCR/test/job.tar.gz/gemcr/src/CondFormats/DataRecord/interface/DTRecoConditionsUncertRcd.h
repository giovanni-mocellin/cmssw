#ifndef DTRecoConditionsUncertRcd_H
#define DTRecoConditionsUncertRcd_H

#include "FWCore/Framework/interface/EventSetupRecordImplementation.h"
class DTRecoConditionsUncertRcd : public edm::eventsetup::EventSetupRecordImplementation<DTRecoConditionsUncertRcd> {};
#endif
