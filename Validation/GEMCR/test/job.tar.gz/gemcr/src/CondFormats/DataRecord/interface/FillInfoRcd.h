#ifndef DataRecord_FillInfoRcd_h
#define DataRecord_FillInfoRcd_h
// -*- C++ -*-
//
// Package:     DataRecord
// Class  :     FillInfoRcd
// 
/**\class FillInfoRcd FillInfoRcd.h CondFormats/DataRecord/interface/FillInfoRcd.h

 Description: [one line class summary]

 Usage:
    <usage>

*/
//
// Author:      
// Created:     Tue Apr 10 19:38:43 CEST 2012
// $Id$
//

#include "FWCore/Framework/interface/EventSetupRecordImplementation.h"

class FillInfoRcd : public edm::eventsetup::EventSetupRecordImplementation<FillInfoRcd> {};

#endif
