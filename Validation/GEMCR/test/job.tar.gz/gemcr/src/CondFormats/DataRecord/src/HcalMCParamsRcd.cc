#include "CondFormats/DataRecord/interface/HcalMCParamsRcd.h"
#include "FWCore/Framework/interface/eventsetuprecord_registration_macro.h"
EVENTSETUP_RECORD_REG(HcalMCParamsRcd);
