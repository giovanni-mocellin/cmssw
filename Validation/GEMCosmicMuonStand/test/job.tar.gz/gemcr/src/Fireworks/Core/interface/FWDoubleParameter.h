#ifndef Fireworks_Core_FWDoubleParameter_h
#define Fireworks_Core_FWDoubleParameter_h
// -*- C++ -*-
//
// Package:     Core
// Class  :     FWDoubleParameter
#include "Fireworks/Core/interface/FWParameters.h"
#endif
