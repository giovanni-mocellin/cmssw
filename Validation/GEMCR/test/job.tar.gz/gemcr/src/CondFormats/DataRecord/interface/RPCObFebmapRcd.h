#ifndef DataRecord_RPCObFebmapRcd_h
#define DataRecord_RPCObFebmapRcd_h
// -*- C++ -*-
//
// Package:     DataRecord
// Class  :     RPCObFebmapRcd
// 
/**\class RPCObFebmapRcd RPCObFebmapRcd.h CondFormats/DataRecord/interface/RPCObFebmapRcd.h

 Description: <one line class summary>

 Usage:
    <usage>

*/
//
// Author:      
// Created:     Thu Feb 26 10:06:35 CET 2009
// $Id$
//

#include "FWCore/Framework/interface/EventSetupRecordImplementation.h"

class RPCObFebmapRcd : public edm::eventsetup::EventSetupRecordImplementation<RPCObFebmapRcd> {};

#endif
