#ifndef CondFormats_DataRecord_EcalWeightXtalGroupsRcd_H
#define CondFormats_DataRecord_EcalWeightXtalGroupsRcd_H

#include "FWCore/Framework/interface/EventSetupRecordImplementation.h"
class EcalWeightXtalGroupsRcd : public edm::eventsetup::EventSetupRecordImplementation<EcalWeightXtalGroupsRcd> {};
#endif
