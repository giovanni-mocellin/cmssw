// -*- C++ -*-
//
// Package:     DataRecord
// Class  :     HeavyIonRcd
// 
// Implementation:
//     <Notes on implementation>
//
// Author:      
// Created:     Tue Jul 10 05:49:16 EDT 2007
// $Id: HeavyIonRcd.cc,v 1.1 2007/11/06 13:01:35 yilmaz Exp $

#include "CondFormats/DataRecord/interface/HeavyIonRPRcd.h"
#include "FWCore/Framework/interface/eventsetuprecord_registration_macro.h"

EVENTSETUP_RECORD_REG(HeavyIonRPRcd);
