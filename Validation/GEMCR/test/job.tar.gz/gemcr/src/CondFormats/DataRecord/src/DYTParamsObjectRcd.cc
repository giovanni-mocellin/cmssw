// Package: CondFormats
// Class  : DYTParamsObjectRcd

#include "CondFormats/DataRecord/interface/DYTParamsObjectRcd.h"
#include "FWCore/Framework/interface/eventsetuprecord_registration_macro.h"

EVENTSETUP_RECORD_REG(DYTParamsObjectRcd);
