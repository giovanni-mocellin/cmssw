#ifndef DataRecord_DQMXMLFileRcd_h
#define DataRecord_DQMXMLFileRcd_h
// -*- C++ -*-
//
// Package:     DataRecord
// Class  :     DQMReferenceHistogramRootFileRcd
// 
/**\class DQMReferenceHistogramRootFileRcd DQMReferenceHistogramRootFileRcd.h CondFormats/DataRecord/interface/DQMReferenceHistogramRootFileRcd.h

 Description: <one line class summary>

 Usage:
    <usage>

*/
//
// Author:      
// Created:     Tue Jul  7 20:29:25 CEST 2009
// $Id: DQMReferenceHistogramRootFileRcd.h,v 1.1 2009/07/20 17:08:07 diguida Exp $
//

#include "FWCore/Framework/interface/EventSetupRecordImplementation.h"

class DQMXMLFileRcd : public edm::eventsetup::EventSetupRecordImplementation<DQMXMLFileRcd> {};

#endif
