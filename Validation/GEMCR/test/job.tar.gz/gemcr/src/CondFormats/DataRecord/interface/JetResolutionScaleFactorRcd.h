#ifndef JetResolutionScaleFactorRcd_h
#define JetResolutionScaleFactorRcd_h
// -*- C++ -*-
// Author: Sébastien Brochet
//

#include "FWCore/Framework/interface/EventSetupRecordImplementation.h"

class JetResolutionScaleFactorRcd : public edm::eventsetup::EventSetupRecordImplementation<JetResolutionScaleFactorRcd> {};

#endif
