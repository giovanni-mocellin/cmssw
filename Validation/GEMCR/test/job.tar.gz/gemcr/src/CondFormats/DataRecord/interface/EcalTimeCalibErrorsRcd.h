#ifndef CondFormats_DataRecord_EcalTimeCalibErrorsRcd_H
#define CondFormats_DataRecord_EcalTimeCalibErrorsRcd_H

#include "FWCore/Framework/interface/EventSetupRecordImplementation.h"
class EcalTimeCalibErrorsRcd : public edm::eventsetup::EventSetupRecordImplementation<EcalTimeCalibErrorsRcd> {};
#endif
