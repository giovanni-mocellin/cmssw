#ifndef DataRecord_EcalLaserAPDPNRatiosRcd_h
#define DataRecord_EcalLaserAPDPNRatiosRcd_h
// -*- C++ -*-
//
// Package:     DataRecord
// Class  :     EcalLaserAPDPNRatiosRcd
// 
/**\class EcalLaserAPDPNRatiosRcd EcalLaserAPDPNRatiosRcd.h CondFormats/DataRecord/interface/EcalLaserAPDPNRatiosRcd.h

 Description: <one line class summary>

 Usage:
    <usage>

*/
//
// Author:      
// Created:     Fri Jun  1 12:30:43 CEST 2007
// $Id$
//

#include "FWCore/Framework/interface/EventSetupRecordImplementation.h"

class EcalLaserAPDPNRatiosRcd : public edm::eventsetup::EventSetupRecordImplementation<EcalLaserAPDPNRatiosRcd> {};

#endif
