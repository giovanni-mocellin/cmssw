#ifndef DataRecord_RPCObAlignmentRcd_h
#define DataRecord_RPCObAlignmentRcd_h
// -*- C++ -*-
//
// Package:     DataRecord
// Class  :     RPCObAlignmentRcd
// 
/**\class RPCObAlignmentRcd RPCObAlignmentRcd.h CondFormats/DataRecord/interface/RPCObAlignmentRcd.h

 Description: <one line class summary>

 Usage:
    <usage>

*/
//
// Author:      
// Created:     Tue Mar 24 11:26:21 CET 2009
// $Id$
//

#include "FWCore/Framework/interface/EventSetupRecordImplementation.h"

class RPCObAlignmentRcd : public edm::eventsetup::EventSetupRecordImplementation<RPCObAlignmentRcd> {};

#endif
