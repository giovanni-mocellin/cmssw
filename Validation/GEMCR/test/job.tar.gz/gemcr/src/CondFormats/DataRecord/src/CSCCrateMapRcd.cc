#include "CondFormats/DataRecord/interface/CSCCrateMapRcd.h"
#include "FWCore/Framework/interface/eventsetuprecord_registration_macro.h"

EVENTSETUP_RECORD_REG(CSCCrateMapRcd);
