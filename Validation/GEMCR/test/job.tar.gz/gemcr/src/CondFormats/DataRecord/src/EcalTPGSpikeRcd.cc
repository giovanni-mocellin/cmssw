#include "CondFormats/DataRecord/interface/EcalTPGSpikeRcd.h"
#include "FWCore/Framework/interface/eventsetuprecord_registration_macro.h"

EVENTSETUP_RECORD_REG(EcalTPGSpikeRcd);
