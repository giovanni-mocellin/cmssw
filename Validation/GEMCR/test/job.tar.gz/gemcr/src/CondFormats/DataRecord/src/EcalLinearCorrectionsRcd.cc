#include "CondFormats/DataRecord/interface/EcalLinearCorrectionsRcd.h"
#include "FWCore/Framework/interface/eventsetuprecord_registration_macro.h"

EVENTSETUP_RECORD_REG(EcalLinearCorrectionsRcd);
