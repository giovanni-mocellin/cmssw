// -*- C++ -*-
//
// Package:     DataRecord
// Class  :     EcalLaserAPDPNRatiosRcd
// 
// Implementation:
//     <Notes on implementation>
//
// Author:      
// Created:     Fri Jun  1 12:30:43 CEST 2007
// $Id$

#include "CondFormats/DataRecord/interface/EcalLaserAPDPNRatiosRcd.h"
#include "FWCore/Framework/interface/eventsetuprecord_registration_macro.h"

EVENTSETUP_RECORD_REG(EcalLaserAPDPNRatiosRcd);
