// -*- C++ -*-
//
// Package:     DataRecord
// Class  :     DQMReferenceHistogramRootFileRcd
// 
// Implementation:
//     <Notes on implementation>
//
// Author:      
// Created:     Tue Jul  7 20:29:25 CEST 2009
// $Id$

#include "CondFormats/DataRecord/interface/DQMReferenceHistogramRootFileRcd.h"
#include "FWCore/Framework/interface/eventsetuprecord_registration_macro.h"

EVENTSETUP_RECORD_REG(DQMReferenceHistogramRootFileRcd);
