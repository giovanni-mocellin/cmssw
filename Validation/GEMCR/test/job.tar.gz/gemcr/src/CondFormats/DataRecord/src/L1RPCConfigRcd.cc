// -*- C++ -*-
//
// Package:     DataRecord
// Class  :     L1RPCConfigRcd
// 
// Implementation:
//     <Notes on implementation>
//
// Author:      
// Created:     Tue Mar 20 14:39:09 CET 2007
// $Id$

#include "CondFormats/DataRecord/interface/L1RPCConfigRcd.h"
#include "FWCore/Framework/interface/eventsetuprecord_registration_macro.h"

EVENTSETUP_RECORD_REG(L1RPCConfigRcd);
