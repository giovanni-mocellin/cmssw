#ifndef DTHVStatusRCD_H
#define DTHVStatusRCD_H

#include "FWCore/Framework/interface/EventSetupRecordImplementation.h"
class DTHVStatusRcd : public edm::eventsetup::EventSetupRecordImplementation<DTHVStatusRcd> {};
#endif
