// -*- C++ -*-
//
// Package:     DataRecord
// Class  :     SiPixelTemplateDBObject0TRcd
// 
// Implementation:
//     <Notes on implementation>
//
// Author:      
// Created:     Mon Sep 28 15:40:32 CEST 2009
// $Id$

#include "CondFormats/DataRecord/interface/SiPixelTemplateDBObject0TRcd.h"
#include "FWCore/Framework/interface/eventsetuprecord_registration_macro.h"

EVENTSETUP_RECORD_REG(SiPixelTemplateDBObject0TRcd);
