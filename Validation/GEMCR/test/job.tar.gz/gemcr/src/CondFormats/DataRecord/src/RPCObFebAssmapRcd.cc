// -*- C++ -*-
//
// Package:     DataRecord
// Class  :     RPCObFebAssmapRcd
// 
// Implementation:
//     <Notes on implementation>
//
// Author:      
// Created:     Thu Mar 26 18:13:51 CET 2009
// $Id$

#include "CondFormats/DataRecord/interface/RPCObFebAssmapRcd.h"
#include "FWCore/Framework/interface/eventsetuprecord_registration_macro.h"

EVENTSETUP_RECORD_REG(RPCObFebAssmapRcd);
