// -*- C++ -*-
//
// Package:     DataRecord
// Class  :     RPCObGasmapRcd
// 
// Implementation:
//     <Notes on implementation>
//
// Author:      
// Created:     Thu Feb 26 10:36:36 CET 2009
// $Id$

#include "CondFormats/DataRecord/interface/RPCObGasmapRcd.h"
#include "FWCore/Framework/interface/eventsetuprecord_registration_macro.h"

EVENTSETUP_RECORD_REG(RPCObGasmapRcd);
