#include "CondFormats/DataRecord/interface/EcalIntercalibErrorsRcd.h"
#include "FWCore/Framework/interface/eventsetuprecord_registration_macro.h"

EVENTSETUP_RECORD_REG(EcalIntercalibErrorsRcd);
