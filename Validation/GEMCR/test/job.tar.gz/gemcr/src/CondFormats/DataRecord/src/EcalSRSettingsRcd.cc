#include "CondFormats/DataRecord/interface/EcalSRSettingsRcd.h"
#include "FWCore/Framework/interface/eventsetuprecord_registration_macro.h"

EVENTSETUP_RECORD_REG(EcalSRSettingsRcd);
