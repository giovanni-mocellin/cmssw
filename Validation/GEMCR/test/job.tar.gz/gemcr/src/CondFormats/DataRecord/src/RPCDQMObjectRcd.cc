// -*- C++ -*-
//
// Package:     DataRecord
// Class  :     RPCDQMObjectRcd
// 
// Implementation:
//     [Notes on implementation]
//
// Author:      
// Created:     Mon Feb  7 17:00:06 CET 2011
// $Id: RPCDQMObjectRcd.cc,v 1.1 2011/02/07 16:41:23 tjkim Exp $

#include "CondFormats/DataRecord/interface/RPCDQMObjectRcd.h"
#include "FWCore/Framework/interface/eventsetuprecord_registration_macro.h"

EVENTSETUP_RECORD_REG(RPCDQMObjectRcd);
