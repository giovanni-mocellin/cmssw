#include "CondFormats/DataRecord/interface/PedestalsRcd.h"
#include "FWCore/Framework/interface/eventsetuprecord_registration_macro.h"

EVENTSETUP_RECORD_REG(PedestalsRcd);
EVENTSETUP_RECORD_REG(anotherPedestalsRcd);

