// -*- C++ -*-
//
// Package:     CondFormats/DataRecord
// Class  :     HFPhase1PMTParamsRcd
// 
// Implementation:
//     [Notes on implementation]
//
// Author:      Igor Volobouev
// Created:     Thu Jul 21 18:25:34 CDT 2016

#include "CondFormats/DataRecord/interface/HFPhase1PMTParamsRcd.h"
#include "FWCore/Framework/interface/eventsetuprecord_registration_macro.h"

EVENTSETUP_RECORD_REG(HFPhase1PMTParamsRcd);
