#include "CondFormats/DataRecord/interface/OpticalAlignmentsRcd.h"
#include "FWCore/Framework/interface/eventsetuprecord_registration_macro.h"
// #include "FWCore/Modules/src/SealModule.cc"
// #include "FWCore/Framework/interface/SourceFactory.h"

EVENTSETUP_RECORD_REG(OpticalAlignmentsRcd);
// DEFINE_FWK_EVENTSETUP_SOURCE(OpticalAlignmentsRcd);
