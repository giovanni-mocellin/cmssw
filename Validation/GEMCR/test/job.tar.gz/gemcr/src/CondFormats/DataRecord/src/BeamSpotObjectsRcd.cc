// -*- C++ -*-
//
// Package:     DataRecord
// Class  :     BeamSpotObjectsRcd
// 
// Implementation:
//     <Notes on implementation>
//
// Author:      
// Created:     Tue Mar  6 19:34:33 CST 2007
// $Id$

#include "CondFormats/DataRecord/interface/BeamSpotObjectsRcd.h"
#include "FWCore/Framework/interface/eventsetuprecord_registration_macro.h"

EVENTSETUP_RECORD_REG(BeamSpotObjectsRcd);
