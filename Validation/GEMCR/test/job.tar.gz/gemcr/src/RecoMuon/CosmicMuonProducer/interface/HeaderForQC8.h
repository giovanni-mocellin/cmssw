#ifndef CosmicMuonProducer_HeaderForQC8_H
#define CosmicMuonProducer_HeaderForQC8_H


#define QC8FLAG_SEEDINFO_MASK_REFVERTROLL18  0x00000001

#define QC8FLAG_SEEDINFO_MASK_DIFFCOL        0x00000006
#define QC8FLAG_SEEDINFO_SHIFT_DIFFCOL       1

#define QC8FLAG_SEEDINFO_MASK_DIFFROLL       0x00000038
#define QC8FLAG_SEEDINFO_SHIFT_DIFFROLL      3


#endif //CosmicMuonProducer_HeaderForQC8_H
