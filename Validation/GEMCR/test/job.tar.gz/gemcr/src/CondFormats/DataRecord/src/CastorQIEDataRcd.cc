// -*- C++ -*-
//
// Package:     DataRecord
// Class  :     CastorQIEDataRcd
// 
// Implementation:
//     <Notes on implementation>
//
// Author:      
// Created:     Mon Feb 11 12:18:26 CET 2008
// $Id: CastorQIEDataRcd.cc,v 1.1 2008/02/15 15:53:56 mccauley Exp $

#include "CondFormats/DataRecord/interface/CastorQIEDataRcd.h"
#include "FWCore/Framework/interface/eventsetuprecord_registration_macro.h"

EVENTSETUP_RECORD_REG(CastorQIEDataRcd);
