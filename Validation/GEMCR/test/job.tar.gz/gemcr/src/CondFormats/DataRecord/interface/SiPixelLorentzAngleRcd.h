#ifndef DataRecord_SiPixelLorentzAngleRcd_h
#define DataRecord_SiPixelLorentzAngleRcd_h
// -*- C++ -*-
//
// Package:     DataRecord
// Class  :     SiPixelLorentzAngleRcd
// 
/**\class SiPixelLorentzAngleRcd SiPixelLorentzAngleRcd.h CondFormats/DataRecord/interface/SiPixelLorentzAngleRcd.h

 Description: <one line class summary>

 Usage:
    <usage>

*/
//
// Author:      
// Created:     Mon Jun 25 15:48:11 CEST 2007
// $Id$
//

#include "FWCore/Framework/interface/EventSetupRecordImplementation.h"

class SiPixelLorentzAngleRcd : public edm::eventsetup::EventSetupRecordImplementation<SiPixelLorentzAngleRcd> {};

#endif
