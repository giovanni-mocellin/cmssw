// -*- C++ -*-
//
// Package:     DataRecord
// Class  :     L1HtMissScaleRcd
// 
// Implementation:
//     <Notes on implementation>
//
// Author:      Jim Brooke
// Created:     Wed Oct  4 16:49:43 CEST 2006
// $Id: 

#include "CondFormats/DataRecord/interface/L1HtMissScaleRcd.h"
#include "FWCore/Framework/interface/eventsetuprecord_registration_macro.h"

EVENTSETUP_RECORD_REG(L1HtMissScaleRcd);
