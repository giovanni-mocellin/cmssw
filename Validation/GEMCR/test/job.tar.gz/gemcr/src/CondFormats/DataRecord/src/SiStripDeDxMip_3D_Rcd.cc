#include "CondFormats/DataRecord/interface/SiStripDeDxMip_3D_Rcd.h"
#include "FWCore/Framework/interface/eventsetuprecord_registration_macro.h"

EVENTSETUP_RECORD_REG(SiStripDeDxMip_3D_Rcd);
