// -*- C++ -*-
//
// Package:     DataRecord
// Class  :     ConfObjectRcd
// 
// Implementation:
//     [Notes on implementation]
//
// Author:      
// Created:     Tue Jan 18 11:27:43 CET 2011
// $Id$

#include "CondFormats/DataRecord/interface/ConfObjectRcd.h"
#include "FWCore/Framework/interface/eventsetuprecord_registration_macro.h"

EVENTSETUP_RECORD_REG(ConfObjectRcd);
