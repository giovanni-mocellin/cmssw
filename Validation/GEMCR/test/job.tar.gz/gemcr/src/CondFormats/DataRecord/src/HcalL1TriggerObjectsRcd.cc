// -*- C++ -*-
//
// Package:     DataRecord
// Class  :     HcalL1TriggerObjectsRcd
// 
// Implementation:
//     <Notes on implementation>
//
// Author:      
// Created:     Fri Nov  7 18:37:16 CET 2008
// $Id$

#include "CondFormats/DataRecord/interface/HcalL1TriggerObjectsRcd.h"
#include "FWCore/Framework/interface/eventsetuprecord_registration_macro.h"

EVENTSETUP_RECORD_REG(HcalL1TriggerObjectsRcd);
