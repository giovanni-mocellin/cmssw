// -*- C++ -*-
//
// Package:     DataRecord
// Class  :     L1JetEtScaleRcd
// 
// Implementation:
//     <Notes on implementation>
//
// Author:      
// Created:     Wed Oct  4 16:49:43 CEST 2006
// $Id: L1JetEtScaleRcd.cc,v 1.1 2006/10/04 14:53:17 jbrooke Exp $

#include "CondFormats/DataRecord/interface/L1JetEtScaleRcd.h"
#include "FWCore/Framework/interface/eventsetuprecord_registration_macro.h"

EVENTSETUP_RECORD_REG(L1JetEtScaleRcd);
