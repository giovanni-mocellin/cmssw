// -*- C++ -*-
//
// Package:     DataRecord
// Class  :     RPCObFebmapRcd
// 
// Implementation:
//     <Notes on implementation>
//
// Author:      
// Created:     Thu Feb 26 10:06:35 CET 2009
// $Id$

#include "CondFormats/DataRecord/interface/RPCObFebmapRcd.h"
#include "FWCore/Framework/interface/eventsetuprecord_registration_macro.h"

EVENTSETUP_RECORD_REG(RPCObFebmapRcd);
