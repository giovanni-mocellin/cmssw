#ifndef CondFormats_DTRecoUncertaintiesRcd_h
#define CondFormats_DTRecoUncertaintiesRcd_h
// -*- C++ -*-
//
// Package:     CondFormats
// Class  :     DTRecoUncertaintiesRcd
// 
/**\class DTRecoUncertaintiesRcd DTRecoUncertaintiesRcd.h src/CondFormats/interface/DTRecoUncertaintiesRcd.h

 Description: [one line class summary]

 Usage:
    <usage>

*/
//
// Author:      
// Created:     Wed Feb 23 11:26:01 CET 2011
// $Id: DTRecoUncertaintiesRcd.h,v 1.1 2011/02/25 14:20:28 cerminar Exp $
//

#include "FWCore/Framework/interface/EventSetupRecordImplementation.h"

class DTRecoUncertaintiesRcd : public edm::eventsetup::EventSetupRecordImplementation<DTRecoUncertaintiesRcd> {};

#endif
