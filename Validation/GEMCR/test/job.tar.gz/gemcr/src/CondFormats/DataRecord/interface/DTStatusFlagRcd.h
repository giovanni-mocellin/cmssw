#ifndef DTSTATUSFLAGRCD_H
#define DTSTATUSFLAGRCD_H

#include "FWCore/Framework/interface/EventSetupRecordImplementation.h"
class DTStatusFlagRcd : public edm::eventsetup::EventSetupRecordImplementation<DTStatusFlagRcd> {};
#endif
