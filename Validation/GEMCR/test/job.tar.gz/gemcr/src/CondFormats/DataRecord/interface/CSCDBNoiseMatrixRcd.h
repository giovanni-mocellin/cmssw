#ifndef CSCDBNOISEMATRIXRCD_H
#define CSCDBNOISEMATRIXRCD_H

#include "FWCore/Framework/interface/EventSetupRecordImplementation.h"
class CSCDBNoiseMatrixRcd : public edm::eventsetup::EventSetupRecordImplementation<CSCDBNoiseMatrixRcd> {};
#endif
