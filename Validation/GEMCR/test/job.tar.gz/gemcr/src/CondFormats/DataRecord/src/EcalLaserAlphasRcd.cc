// -*- C++ -*-
//
// Package:     DataRecord
// Class  :     EcalLaserAlphasRcd
// 
// Implementation:
//     <Notes on implementation>
//
// Author:      
// Created:     Fri Jun  1 12:28:55 CEST 2007
// $Id$

#include "CondFormats/DataRecord/interface/EcalLaserAlphasRcd.h"
#include "FWCore/Framework/interface/eventsetuprecord_registration_macro.h"

EVENTSETUP_RECORD_REG(EcalLaserAlphasRcd);
