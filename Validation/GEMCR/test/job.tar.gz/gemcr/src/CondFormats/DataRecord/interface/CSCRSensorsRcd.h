#ifndef CSCRSENSORSRCD_H
#define CSCRSENSORSRCD_H

#include "FWCore/Framework/interface/EventSetupRecordImplementation.h"
/* #include "FWCore/ParameterSet/interface/ParameterSet.h" */

class CSCRSensorsRcd : public edm::eventsetup::EventSetupRecordImplementation<CSCRSensorsRcd> {
    
};

#endif
