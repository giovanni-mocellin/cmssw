#ifndef DTDEADFLAGRCD_H
#define DTDEADFLAGRCD_H

#include "FWCore/Framework/interface/EventSetupRecordImplementation.h"
class DTDeadFlagRcd : public edm::eventsetup::EventSetupRecordImplementation<DTDeadFlagRcd> {};
#endif
