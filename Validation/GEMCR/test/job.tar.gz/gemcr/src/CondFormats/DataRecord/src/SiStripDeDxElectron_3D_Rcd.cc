#include "CondFormats/DataRecord/interface/SiStripDeDxElectron_3D_Rcd.h"
#include "FWCore/Framework/interface/eventsetuprecord_registration_macro.h"

EVENTSETUP_RECORD_REG(SiStripDeDxElectron_3D_Rcd);
