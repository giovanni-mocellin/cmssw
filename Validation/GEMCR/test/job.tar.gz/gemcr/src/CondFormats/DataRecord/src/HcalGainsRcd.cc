// this file is generated automatically by /afs/fnal.gov/files/home/room1/ratnikov/bin/makeNewClass.sh
// name: ratnikov, date: Mon Sep 26 17:02:30 CDT 2005
#include "CondFormats/DataRecord/interface/HcalGainsRcd.h"
#include "FWCore/Framework/interface/eventsetuprecord_registration_macro.h"
EVENTSETUP_RECORD_REG(HcalGainsRcd);
