// -*- C++ -*-
//
// Package:     DataRecord
// Class  :     L1TriggerScalerRcd
// 
// Implementation:
//     <Notes on implementation>
//
// Author:      
// Created:     Thu Aug 21 11:47:50 CEST 2008
// $Id$

#include "CondFormats/DataRecord/interface/L1TriggerScalerRcd.h"
#include "FWCore/Framework/interface/eventsetuprecord_registration_macro.h"

EVENTSETUP_RECORD_REG(L1TriggerScalerRcd);
