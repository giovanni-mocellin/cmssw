#include "CondFormats/DataRecord/interface/ExEfficiency.h"
#include "FWCore/Framework/interface/eventsetuprecord_registration_macro.h"

EVENTSETUP_RECORD_REG(ExEfficiencyRcd);
EVENTSETUP_RECORD_REG(ExDwarfRcd);
EVENTSETUP_RECORD_REG(ExDwarfListRcd);


