#ifndef DataRecord_SiPixelGainCalibrationForHLTRcd_h
#define DataRecord_SiPixelGainCalibrationForHLTRcd_h
// -*- C++ -*-
//
// Package:     DataRecord
// Class  :     SiPixelGainCalibrationForHLTRcd
// 
/**\class SiPixelGainCalibrationForHLTRcd SiPixelGainCalibrationForHLTRcd.h CondFormats/DataRecord/interface/SiPixelGainCalibrationForHLTRcd.h

 Description: <one line class summary>

 Usage:
    <usage>

*/
//
// Author:      
// Created:     Tue Oct  3 19:11:28 CEST 2006
// $Id: SiPixelGainCalibrationForHLTRcd.h,v 1.1 2006/10/20 09:09:15 chiochia Exp $
//

#include "FWCore/Framework/interface/EventSetupRecordImplementation.h"

class SiPixelGainCalibrationForHLTRcd : public edm::eventsetup::EventSetupRecordImplementation<SiPixelGainCalibrationForHLTRcd> {};

#endif
