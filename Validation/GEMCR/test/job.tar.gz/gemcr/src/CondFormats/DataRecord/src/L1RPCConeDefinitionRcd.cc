// -*- C++ -*-
//
// Package:     CondFormats
// Class  :     L1RPCConeDefinitionRcd.cc
// 
// Implementation:
//     <Notes on implementation>
//

#include "CondFormats/DataRecord/interface/L1RPCConeDefinitionRcd.h"
#include "FWCore/Framework/interface/eventsetuprecord_registration_macro.h"

EVENTSETUP_RECORD_REG(L1RPCConeDefinitionRcd);
