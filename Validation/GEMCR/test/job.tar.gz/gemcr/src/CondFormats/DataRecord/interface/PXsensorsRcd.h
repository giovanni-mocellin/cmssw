#ifndef OptAlignObjects_PXsensorsRcd_h
#define OptAlignObjects_PXsensorsRcd_h
// -*- C++ -*-
//
// Package:     OptAlignObjects
// Class  :     PXsensorsRcd
// 
/**\class PXsensorsRcd PXsensorsRcd.h CondFormats/OptAlignObjects/interface/PXsensorsRcd.h

 Description: <one line class summary>

 Usage:
    <usage>

*/
//
// Author:      
// Created:     Thu Jul 20 14:30:27 CEST 2006
// $Id: PX_sensorsRcd.h,v 1.1 2006/08/01 12:00:10 kdziedzi Exp $
//

#include "FWCore/Framework/interface/EventSetupRecordImplementation.h"

class PXsensorsRcd : public edm::eventsetup::EventSetupRecordImplementation<PXsensorsRcd> {};

#endif
