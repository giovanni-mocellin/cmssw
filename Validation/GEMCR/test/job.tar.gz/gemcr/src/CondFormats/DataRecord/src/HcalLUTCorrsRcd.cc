// -*- C++ -*-
//
// Package:     DataRecord
// Class  :     HcalLUTCorrsRcd
// 
// Implementation:
//     <Notes on implementation>
//
// Author:      
// Created:     Sat Mar  1 15:49:28 CET 2008
// $Id: HcalLUTCorrsRcd.cc,v 1.1 2008/03/03 16:58:17 rofierzy Exp $

#include "CondFormats/DataRecord/interface/HcalLUTCorrsRcd.h"
#include "FWCore/Framework/interface/eventsetuprecord_registration_macro.h"

EVENTSETUP_RECORD_REG(HcalLUTCorrsRcd);
