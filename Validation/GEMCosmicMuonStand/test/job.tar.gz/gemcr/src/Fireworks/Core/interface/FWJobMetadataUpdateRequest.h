#ifndef Fireworks_Core_FWJobMetadataUpdateRequest
#define Fireworks_Core_FWJobMetadataUpdateRequest

class FWJobMetadataUpdateRequest
{
public:
   virtual ~FWJobMetadataUpdateRequest() {};
};

#endif