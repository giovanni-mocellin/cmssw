// name: kukartse, date: Wed Feb 03 18:19:54 CDT 2010
#include "CondFormats/DataRecord/interface/HcalDcsMapRcd.h"
#include "FWCore/Framework/interface/eventsetuprecord_registration_macro.h"
EVENTSETUP_RECORD_REG(HcalDcsMapRcd);
