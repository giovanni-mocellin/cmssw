#ifndef CondFormats_SiStripDeDxPion_3D_Rcd_h
#define CondFormats_SiStripDeDxPion_3D_Rcd_h

#include "FWCore/Framework/interface/EventSetupRecordImplementation.h"

class SiStripDeDxPion_3D_Rcd : public edm::eventsetup::EventSetupRecordImplementation<SiStripDeDxPion_3D_Rcd> {};

#endif
