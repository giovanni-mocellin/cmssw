// -*- C++ -*-
//
// Package:     DataRecord
// Class  :     RPCObUXCRcd
// 
// Implementation:
//     <Notes on implementation>
//
// Author:      
// Created:     Mon Nov 16 12:18:42 CET 2009
// $Id$

#include "CondFormats/DataRecord/interface/RPCObUXCRcd.h"
#include "FWCore/Framework/interface/eventsetuprecord_registration_macro.h"

EVENTSETUP_RECORD_REG(RPCObUXCRcd);
