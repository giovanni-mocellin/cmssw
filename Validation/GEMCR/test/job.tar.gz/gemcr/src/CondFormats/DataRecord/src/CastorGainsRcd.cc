// -*- C++ -*-
//
// Package:     DataRecord
// Class  :     CastorGainsRcd
// 
// Implementation:
//     <Notes on implementation>
//
// Author:      
// Created:     Mon Feb 11 12:16:54 CET 2008
// $Id: CastorGainsRcd.cc,v 1.1 2008/02/15 15:53:55 mccauley Exp $

#include "CondFormats/DataRecord/interface/CastorGainsRcd.h"
#include "FWCore/Framework/interface/eventsetuprecord_registration_macro.h"

EVENTSETUP_RECORD_REG(CastorGainsRcd);
