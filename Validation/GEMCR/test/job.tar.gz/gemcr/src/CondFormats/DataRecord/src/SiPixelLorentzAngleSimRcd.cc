// -*- C++ -*-
//
// Package:     DataRecord
// Class  :     SiPixelLorentzAngleSimRcd
// 
// Implementation:
//     <Notes on implementation>
//
// Author:      
// Created:     Fri Mar 13 12:13:25 CET 2009
// $Id$

#include "CondFormats/DataRecord/interface/SiPixelLorentzAngleSimRcd.h"
#include "FWCore/Framework/interface/eventsetuprecord_registration_macro.h"

EVENTSETUP_RECORD_REG(SiPixelLorentzAngleSimRcd);
