// -*- C++ -*-
//
// Package:     DataRecord
// Class  :     SiPixelCalibConfigurationRcd
// 
// Implementation:
//     <Notes on implementation>
//
// Author:      
// Created:     Thu Feb 14 20:27:08 CET 2008
// $Id$

#include "CondFormats/DataRecord/interface/SiPixelCalibConfigurationRcd.h"
#include "FWCore/Framework/interface/eventsetuprecord_registration_macro.h"

EVENTSETUP_RECORD_REG(SiPixelCalibConfigurationRcd);
