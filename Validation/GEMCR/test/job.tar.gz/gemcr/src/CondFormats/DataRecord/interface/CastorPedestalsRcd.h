#ifndef DataRecord_CastorPedestalsRcd_h
#define DataRecord_CastorPedestalsRcd_h
// -*- C++ -*-
//
// Package:     DataRecord
// Class  :     CastorPedestalsRcd
// 
/**\class CastorPedestalsRcd CastorPedestalsRcd.h CondFormats/DataRecord/interface/CastorPedestalsRcd.h

 Description: <one line class summary>

 Usage:
    <usage>

*/
//
// Author:      
// Created:     Mon Feb 11 12:17:40 CET 2008
// $Id: CastorPedestalsRcd.h,v 1.1 2008/02/15 15:53:04 mccauley Exp $
//

#include "FWCore/Framework/interface/EventSetupRecordImplementation.h"

class CastorPedestalsRcd : public edm::eventsetup::EventSetupRecordImplementation<CastorPedestalsRcd> {};

#endif
