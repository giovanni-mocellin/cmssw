// -*- C++ -*-
//
// Package:     CondFormats
// Class  :     L1RPCConeBuilderRcd
// 
// Implementation:
//     <Notes on implementation>
//
// Author:      
// Created:     Fri Feb 22 12:15:57 CET 2008
// $Id$

#include "CondFormats/DataRecord/interface/L1RPCConeBuilderRcd.h"
#include "FWCore/Framework/interface/eventsetuprecord_registration_macro.h"

EVENTSETUP_RECORD_REG(L1RPCConeBuilderRcd);
