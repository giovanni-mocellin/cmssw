// -*- C++ -*-
//
// Package:     DataRecord
// Class  :     RunNumberRcd
// 
// Implementation:
//     <Notes on implementation>
//
// Author:      
// Created:     Wed May 28 11:20:27 CEST 2008
// $Id$

#include "CondFormats/DataRecord/interface/RunNumberRcd.h"
#include "FWCore/Framework/interface/eventsetuprecord_registration_macro.h"

EVENTSETUP_RECORD_REG(RunNumberRcd);
