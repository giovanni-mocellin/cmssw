#include "FWCore/Framework/interface/eventsetuprecord_registration_macro.h"

#include "CondFormats/DataRecord/interface/SiPixelPerformanceSummaryRcd.h"


EVENTSETUP_RECORD_REG(SiPixelPerformanceSummaryRcd);
