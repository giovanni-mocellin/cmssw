#ifndef DataRecord_RBCBoardSpecsRcd_h
#define DataRecord_RBCBoardSpecsRcd_h
// -*- C++ -*-
//
// Package:     DataRecord
// Class  :     RBCBoardSpecsRcd
// 
/**\class RBCBoardSpecsRcd RBCBoardSpecsRcd.h CondFormats/DataRecord/interface/RBCBoardSpecsRcd.h

 Description: <one line class summary>

 Usage:
    <usage>

*/
//
// Author:      
// Created:     Thu Dec 11 17:47:19 CET 2008
// $Id$
//

#include "FWCore/Framework/interface/EventSetupRecordImplementation.h"

class RBCBoardSpecsRcd : public edm::eventsetup::EventSetupRecordImplementation<RBCBoardSpecsRcd> {};

#endif
