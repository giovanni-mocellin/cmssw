#ifndef ECALPULSESYMMCOVARIANCESRCD_H
#define ECALPULSESYMMCOVARIANCESRCD_H

#include "FWCore/Framework/interface/EventSetupRecordImplementation.h"
class EcalPulseSymmCovariancesRcd : public edm::eventsetup::EventSetupRecordImplementation<EcalPulseSymmCovariancesRcd> {};
#endif
