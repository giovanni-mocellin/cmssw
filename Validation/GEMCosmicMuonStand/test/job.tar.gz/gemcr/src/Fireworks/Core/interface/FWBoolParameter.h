#ifndef Fireworks_Core_FWBoolParameter_h
#define Fireworks_Core_FWBoolParameter_h
// -*- C++ -*-
//
// Package:     Core
// Class  :     FWBoolParameter
//
#include "Fireworks/Core/interface/FWParameters.h"
#endif
