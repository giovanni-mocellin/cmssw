#include "CondFormats/DataRecord/interface/EcalTPGLutGroupRcd.h"
#include "FWCore/Framework/interface/eventsetuprecord_registration_macro.h"

EVENTSETUP_RECORD_REG(EcalTPGLutGroupRcd);
