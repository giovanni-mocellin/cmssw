// -*- C++ -*-
//
// Package:     DataRecord
// Class  :     SiPixel2DTemplateDBObjectRcd
// 
// Implementation:
//     <Notes on implementation>
//
// Author:      
// Created:     Tue Nov 11 23:08:00 CET 2008
// $Id: SiPixel2DTemplateDBObjectRcd.cc,v 1.1 2008/11/12 18:13:03 dfehling Exp $

#include "CondFormats/DataRecord/interface/SiPixel2DTemplateDBObjectRcd.h"
#include "FWCore/Framework/interface/eventsetuprecord_registration_macro.h"

EVENTSETUP_RECORD_REG(SiPixel2DTemplateDBObjectRcd);
