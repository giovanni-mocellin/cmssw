#include "CondFormats/DataRecord/interface/SiStripCondDataRecords.h"
