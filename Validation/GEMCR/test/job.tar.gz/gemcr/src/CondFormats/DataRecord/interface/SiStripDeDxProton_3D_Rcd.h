#ifndef CondFormats_SiStripDeDxProton_3D_Rcd_h
#define CondFormats_SiStripDeDxProton_3D_Rcd_h

#include "FWCore/Framework/interface/EventSetupRecordImplementation.h"

class SiStripDeDxProton_3D_Rcd : public edm::eventsetup::EventSetupRecordImplementation<SiStripDeDxProton_3D_Rcd> {};

#endif
