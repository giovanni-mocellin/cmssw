#include "CondFormats/DataRecord/interface/ESIntercalibConstantsRcd.h"
#include "FWCore/Framework/interface/eventsetuprecord_registration_macro.h"

EVENTSETUP_RECORD_REG(ESIntercalibConstantsRcd);
